# Fancy Fragrances

**Module:** WEB DEVELOPMENT (INTRODUCTION) - WEDE5020  
**Part:** 2  
**Student name:** Add your name here  
**Student number:** Add your student number here

## About the website

Fancy Fragrances is a small South African family fragrance and skincare business. The website gives customers a simple way to learn about the brand, browse the catalogue, contact the business, and find upcoming market events.

## Pages

- `home.html` - welcome page, featured products, reviews, and market preview
- `shop.html` - skincare catalogue and perfume launch notice
- `about.html` - the Fancy Fragrances family story
- `contact.html` - contact links and enquiry form
- `damaged-item.html` - damaged product report form
- `markets.html` - upcoming market information

## Technologies

- HTML5 for page structure and accessible form labels
- CSS3 in `css/home.css` for the shared visual design and responsive breakpoints
- Local image assets in `pics/`

## Running the project

Open `home.html` in a browser, or use the Live Server extension in VS Code. No build process or package installation is required.

## Responsive design

The layout has desktop, tablet, and mobile breakpoints. The navigation wraps on smaller screens, product cards resize into fewer columns, forms use the available screen width, and images keep their proportions.

## Part 2 improvements

The Part 2 update includes a more consistent colour palette and typography system, hover and focus states, responsive layout adjustments, improved form styling, new skincare product photography, and a clear notice that perfumes will be added soon. The website uses HTML and CSS only.

## Credits

Content and product concept created for the WEDE5020 portfolio of evidence. Images are local project assets.
