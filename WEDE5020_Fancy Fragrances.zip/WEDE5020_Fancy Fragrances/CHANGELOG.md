# Changelog

## Part 2 - 17 September 2026

- Updated the shared external stylesheet used by all pages.
- Added a consistent colour palette, heading styles, spacing, borders, shadows, and button states.
- Improved the header and navigation layout for wider desktop screens.
- Added hover and keyboard focus styles for links, buttons, form fields, and cards.
- Added tablet and mobile breakpoints for navigation, hero content, product grids, forms, and footer columns.
- Improved image sizing so the banner, product cards, logo, and market image resize without distortion.
- Added project documentation and a references section.
- Added the new skincare product images to the homepage and shop catalogue.
- Replaced placeholder product names with Turmeric Glow Oil, SPF 50 Sunscreen, Vitamin E Hand Lotion, Vitamin E Skin Oil, and Retinol Face Serum.
- Updated the shop to show perfumes as coming soon, with purchasing disabled until the perfume range launches.
- Removed JavaScript functionality and non-working filter controls so Part 2 uses HTML and CSS only.

## Part 1

- Created the initial Fancy Fragrances multi-page website.
- Added the home, shop, about, contact, damaged item, and markets pages.
- Added local image assets and the first shared stylesheet.
